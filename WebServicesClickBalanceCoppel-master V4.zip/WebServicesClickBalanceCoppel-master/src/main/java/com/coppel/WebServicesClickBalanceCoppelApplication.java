package com.coppel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesClickBalanceCoppelApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesClickBalanceCoppelApplication.class, args);

	}



}

package com.coppel.service;

import com.coppel.WebServicesClickBalanceCoppelApplication;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class RegistrarCatalogoArticulosService {

    private static final Logger LOGGER = LogManager.getLogger(WebServicesClickBalanceCoppelApplication.class);



    @Autowired
    private JdbcTemplate jdbcTemplate;

    public String RegistrarCatalogoArticulos(String sXml) {
        String Regresa = "";
        int bandera = 0;

            try {

                Date fechaActual = new Date();
                SimpleDateFormat formato = new SimpleDateFormat("hmmssSSS");
                String cadenaFecha = formato.format(fechaActual);

                File file = new File("articulos" + cadenaFecha + ".xml");
                FileOutputStream fos = new FileOutputStream(file);
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(fos, "UTF8"));
                out.write(sXml);
                out.close();

                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                // Establecer permisos específicos para el propietario
                file.setReadable(true, true);  // Hacer el archivo legible para el propietario
                file.setWritable(true, true);  // Hacer el archivo escribible para el propietario
                file.setExecutable(false, false);  // No permitir la ejecución del archivo por el propietario

                // Establecer permisos específicos para el grupo
                file.setReadable(true, false);  // No hacer el archivo legible para el grupo
                file.setWritable(false, false);  // No hacer el archivo escribible para el grupo
                file.setExecutable(false, false);  // No permitir la ejecución del archivo por el grupo

                // Establecer permisos específicos para otros usuarios
                file.setReadable(false, false);  // No hacer el archivo legible para otros usuarios
                file.setWritable(false, false);  // No hacer el archivo escribible para otros usuarios
                file.setExecutable(false, false); // No permitir la ejecución del archivo por otros usuarios
                dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
                dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
                dbf.setXIncludeAware(false);
                dbf.setExpandEntityReferences(false);
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(file);
                if (file.exists()) {
                    if (!file.delete()) {
                        System.out.println("No se pudo eliminar el archivo de manera segura");
                        
                    }
                }
                doc.getDocumentElement().normalize();
                NodeList nodeLst = doc.getElementsByTagName("registro");
                String susuario = "";
                String scodigo = "";
                String snombrecodigo = "";
                String sclase = "";
                String snombreclase = "";
                String sfamilia = "";
                String snombrefamilia = "";
                String sunidad = "";
                String snombreunidad = "";
                String sestatus = "";
                String sfechaalta = "";
                String scomprador = "";
                String shuesariocentro = "";
                String smuebleenser = "";
                String smedidaespecial = "";
                String sstockbodegaregional = "";
                String stipoart = "";
                String sfoto = "";
                String sql = "";

                for (int s = 0; s < nodeLst.getLength(); ++s) {
                    ++bandera;

                    Node fstNode = nodeLst.item(s);
                    if (fstNode.getNodeType() == 1) {
                        Element fstElmnt = (Element) fstNode;

                        NodeList mvtNmElmntLst = fstElmnt.getElementsByTagName("usuario");
                        Element movto = (Element) mvtNmElmntLst.item(0);
                        NodeList datomovto = movto.getChildNodes();
                        susuario = datomovto.item(0).getNodeValue();

                        mvtNmElmntLst = fstElmnt.getElementsByTagName("codigo");
                        movto = (Element) mvtNmElmntLst.item(0);
                        datomovto = movto.getChildNodes();
                        scodigo = datomovto.item(0).getNodeValue();

                        NodeList usrNmElmntLst = fstElmnt.getElementsByTagName("nombrecodigo");
                        Element usuario = (Element) usrNmElmntLst.item(0);
                        NodeList datousuario = usuario.getChildNodes();
                        snombrecodigo = datousuario.item(0).getNodeValue();

                        NodeList atrzNmElmntLst = fstElmnt.getElementsByTagName("clase");
                        Element autoriza = (Element) atrzNmElmntLst.item(0);
                        NodeList datoautoriza = autoriza.getChildNodes();
                        sclase = datoautoriza.item(0).getNodeValue();

                        NodeList bdgNmElmntLst = fstElmnt.getElementsByTagName("nombreclase");
                        Element bodega = (Element) bdgNmElmntLst.item(0);
                        NodeList datobodega = bodega.getChildNodes();
                        snombreclase = datobodega.item(0).getNodeValue();

                        NodeList ctrNmElmntLst = fstElmnt.getElementsByTagName("familia");
                        Element centro = (Element) ctrNmElmntLst.item(0);
                        NodeList datocentro = centro.getChildNodes();
                        sfamilia = datocentro.item(0).getNodeValue();

                        NodeList tdaNmElmntLst = fstElmnt.getElementsByTagName("nombrefamilia");
                        Element tienda = (Element) tdaNmElmntLst.item(0);
                        NodeList datotienda = tienda.getChildNodes();
                        snombrefamilia = datotienda.item(0).getNodeValue();

                        NodeList ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("unidad");
                        Element centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        NodeList datocentrocargo = centrocargo.getChildNodes();
                        sunidad = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("nombreunidad");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        snombreunidad = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("estatus");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        sestatus = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("fechaalta");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        sfechaalta = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("comprador");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        scomprador = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("huesariocentro");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        shuesariocentro = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("muebleenser");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        smuebleenser = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("medidaespecial");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        smedidaespecial = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("stockbodegaregional");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        sstockbodegaregional = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("tipoart");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        stipoart = datocentrocargo.item(0).getNodeValue();

                        ctrcrgNmElmntLst = fstElmnt.getElementsByTagName("foto");
                        centrocargo = (Element) ctrcrgNmElmntLst.item(0);
                        datocentrocargo = centrocargo.getChildNodes();
                        sfoto = datocentrocargo.item(0).getNodeValue();

                        Class.forName("org.postgresql.Driver");
                       sql = "SELECT CB_RegistrarCatalogoArticulos(:susuario, :scodigo, :snombrecodigo, :sclase, :snombreclase, :sfamilia, :snombrefamilia, :sunidad, :snombreunidad, :sestatus, :sfechaalta, :scomprador, :shuesariocentro, :smuebleenser, :smedidaespecial, :sstockbodegaregional, :stipoart, :sfoto)";

    Map<String, Object> paramMap = new HashMap<>();
    paramMap.put("susuario", susuario);
    paramMap.put("scodigo", scodigo);
    paramMap.put("snombrecodigo", snombrecodigo);
    paramMap.put("sclase", sclase);
    paramMap.put("snombreclase", snombreclase);
    paramMap.put("sfamilia", sfamilia);
    paramMap.put("snombrefamilia", snombrefamilia);
    paramMap.put("sunidad", sunidad);
    paramMap.put("snombreunidad", snombreunidad);
    paramMap.put("sestatus", sestatus);
    paramMap.put("sfechaalta", sfechaalta);
    paramMap.put("scomprador", scomprador);
    paramMap.put("shuesariocentro", shuesariocentro);
    paramMap.put("smuebleenser", smuebleenser);
    paramMap.put("smedidaespecial", smedidaespecial);
    paramMap.put("sstockbodegaregional", sstockbodegaregional);
    paramMap.put("stipoart", stipoart);
    paramMap.put("sfoto", sfoto);

    namedParameterJdbcTemplate.update(sql, paramMap);
                        bandera = 1;
                    }
                }
            } catch (Exception var62) {
                LOGGER.error("Error en el método RegistrarCatalogoArticulos", var62);
                bandera = -1;
                Regresa = "Ocurrió un error al procesar la solicitud. Por favor, contacta al administrador del sistema para obtener más información.";
            }


        if (bandera == 0) {
            LOGGER.error("Error 0");
            return "0";
        } else {
            return bandera == 1 ? "1" : Regresa;

        }





    }




}

package com.coppel.controller;





import com.coppel.clases.RegistrarCatalogoArticulosRequest;
import com.coppel.clases.RegistrarCatalogoArticulosResponse;
import com.coppel.service.RegistrarCatalogoArticulosService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class RegistrarCatalogoArticulosController {
    private static final String NAMESPACE_URI = "http://coppel.com/clases";


    @Autowired
    private RegistrarCatalogoArticulosService registrarCatalogoArticulosService;

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "RegistrarCatalogoArticulosRequest")
    @ResponsePayload
    public RegistrarCatalogoArticulosResponse getCatalogoArticulo(@RequestPayload RegistrarCatalogoArticulosRequest request) {

        RegistrarCatalogoArticulosResponse response = new RegistrarCatalogoArticulosResponse();
        response.setReturn(registrarCatalogoArticulosService.RegistrarCatalogoArticulos(request.getSXml()));

        return response;
    }
}

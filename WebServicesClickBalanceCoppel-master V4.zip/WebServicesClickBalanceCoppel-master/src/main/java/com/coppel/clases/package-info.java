//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2024.04.04 a las 01:26:00 PM GMT-06:00 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://coppel.com/clases", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.coppel.clases;
